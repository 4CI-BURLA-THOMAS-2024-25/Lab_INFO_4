/**
 * classe Negozio:
    -nome
    -city
    -Clienti[]
 * 
 * @author Thomas Burla
 * @version 1.0
 */
import java.util.*;
public class Negozio {
    //variabili d'istanza
    private String nome;
    private String city;
    private ArrayList <Cliente> clienti;
}